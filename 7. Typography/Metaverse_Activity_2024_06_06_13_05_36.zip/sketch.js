var font1;
var word1 = "Bath Spa University";
var word2 = "A";
var word3 = "M";

function preload(){
  font1 = loadFont("COPRGTL.TTF");
}

function setup() {
  createCanvas(400, 400);
  background('#3B4962');
  fill('rgb(207,207,214)');
  rect(125, 70, 150, 150);
  stroke('white');
  strokeWeight(3);
  line(40, 310, 360, 310);
  fill('white');
  strokeWeight(0);
  textFont(font1,30);
  textAlign(CENTER);
  text(word1, width/2, 300);
  fill('red');
  textFont(font1,160);
  textAlign(CENTER);
  text(word2, width/2, 200);
  fill('black');
  textAlign(CENTER);
  text(word3, width/2, 200);
}

function draw() {
}